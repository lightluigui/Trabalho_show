
function tocar1(){
    var audio = new Audio('abyss.wav');
    audio.play();
}

function tocar2(){
    var audio = new Audio('nameless.wav');
    audio.play();
}

function tocar3(){
    var audio = new Audio('lobao.wav');
    audio.play();
}

function tocar4(){
    var audio = new Audio('cinder.wav');
    audio.play();
}

function tocar5(){
    var audio = new Audio('yhorm.wav');
    audio.play();
}


function tocar6(){
    var audio = new Audio('abyss.wav');
    audio.play();
}

function tocar7(){
    var audio = new Audio('dragon.wav');
    audio.play();
}

function tocar8(){
    var audio = new Audio('reis.wav');
    audio.play();
}

function tocar9(){
    var audio = new Audio('gael.wav');
    audio.play();
}

function tocar10(){
    var audio = new Audio('gwyn.wav');
    audio.play();
}


function tocar11(){
    var audio = new Audio('nito.wav');
    audio.play();
}

function tocar12(){
    var audio = new Audio('sulivan.wav');
    audio.play();
}

function rodrigofaro(){
    var audio = new Audio('Efeitos.wav');
    audio.play();
}




//funçao criada para quando clicar no botao indice apareça os tiers
var clicado = false;
function indices(){
    var tiers = ['tier 1', 'tier 2', 'tier 3', 'tier 4', 'tier 5', 'tier 6', 'sobre']
    if(!clicado){
        const novo = document.createElement("li")
        novo.innerHTML = tiers.slice([-8]).join('<br><li>')
        document.getElementById("add").append(novo)
        clicado = true;
    }
    
}



